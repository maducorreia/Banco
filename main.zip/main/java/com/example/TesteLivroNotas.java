package com.example;

public class TesteLivroNotas {
    public static void main(String[] args) {
/*
        String s1 = new String("Isto é uma string");
        String s2 = new String("Isto é uma string");

        System.out.println(s1.equals(s2));
        
        */
        


        /*LivroNotas livroNotas = new LivroNotas();
        double nota=0.0;

        while (nota>=0){
            int qtd = livroNotas.getqtdNotas() + 1;
            nota = Double.parseDouble(JOptionPane.showInputDialog("nota" + qtd + ":"));
            if (nota<0)
                break;
            livroNotas.adicionarNotas(nota);
        }

        System.out.println(livroNotas.calcularMedia());
*/
    }
}