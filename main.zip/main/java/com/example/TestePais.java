package com.example;

public class TestePais {
    public static void main(String[] args) {
        Pais paisA = new Pais("Brasil", "buenos", 157.5);
        Pais paisB = new Pais("Brasil", "buenos", 150);

        if (paisA.equals(paisB)){
            System.out.println("iguais");
        }else
            System.out.println("diferentes");
    }
}
