package com.example;

public class Pais{
    private String nome;
    private String capital;
    private double dimensao;

    public Pais (String nome, String capital, double dimensao){
        this.nome = nome;
        this.capital = capital;
        this.dimensao = dimensao;
    }

    public boolean equals(Object o){
        if (o instanceof Pais){
            Pais novoPais = (Pais)o;
            if (this.nome.equals(novoPais.nome) && this.capital.equals(novoPais.capital)){
                return true;
            }
        }
        return false;
    }

}