package com.example;

public class LivroNotas {
    private double somaNotas;
    private int qtdNotas; 
    
    public LivroNotas(){
        this.qtdNotas = 0;
        this.somaNotas = 0.0;
    }

    public int getqtdNotas(){
        return qtdNotas;
    }

    public void adicionarNotas(double nota){
        somaNotas += nota;
        qtdNotas += 1;
    }

    public double calcularMedia(){
        double media = somaNotas / qtdNotas;
        return media;
    }

}
